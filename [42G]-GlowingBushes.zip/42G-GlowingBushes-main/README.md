# 42G-GlowingBushes

Rimworld Patch, Glowing Bushes,  Simple XML patching to give harvestable bushes in Rimworld a glow effect.

This is a simple XML patch for the native harvestable bushes in Rimworld. These include berry bush, strawberry, healroot and ambrosia. The initial idea came from Glowing Healroot Mod by Syrchalis which I have included his code and texture for healroot and credited in the about.xml.  On his mod page there was a request to make all bushes glow and so as part of my learning projects I created this mod patch to include all bushes known to me.  As an addition to the native harvest bushes I included a patch for Alpha Animals heat resistant Ambrosia which I discovered during my searches.

I have been unable to request permission from Syrchalis and so I went ahead and included his healroot patch and textures. If this is not ok let me know and I will remove the textures. As the def patch code is pretty much universal this will remain.
